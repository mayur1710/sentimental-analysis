from flask import Flask, render_template, request
import pickle

app = Flask(__name__)

# Load the trained model
with open('model.pkl', 'rb') as model_file:
    model = pickle.load(model_file)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    review = request.form['review']
    cleaned_review = preprocess_review(review)
    prediction = model.predict([cleaned_review])[0]
    if prediction == 1:
        sentiment = 'Positive'
    else:
        sentiment = 'Negative'
    return render_template('result.html', review=review, sentiment=sentiment)

def preprocess_review(review):
    # Implement your text preprocessing steps here
    return review

if __name__ == '__main__':
    app.run(debug=True)
