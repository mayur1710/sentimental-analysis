import pandas as pd
import re
import nltk
from nltk.corpus import stopwords
from nltk.tokenize import word_tokenize
from nltk.stem import WordNetLemmatizer
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.model_selection import train_test_split
from sklearn.linear_model import LogisticRegression
from flask import Flask, render_template, request
import pickle

# Load dataset
data = pd.read_csv("/content/extracted_files/reviews_tawa/data.csv")

# Drop rows with missing values
data.dropna(subset=['Review_Text', 'Reviewer_Rating'], inplace=True)

# Convert 'Reviewer_Rating' to binary sentiment labels (positive: 1, negative: 0)
data['Sentiment'] = data['Reviewer_Rating'].apply(lambda x: 1 if x > 3 else 0)

# Define function for text cleaning and normalization
def clean_text(text):
    text = text.lower()
    text = re.sub(r'[^a-zA-Z\s]', '', text)
    tokens = word_tokenize(text)
    stop_words = set(stopwords.words('english'))
    tokens = [word for word in tokens if word not in stop_words]
    lemmatizer = WordNetLemmatizer()
    tokens = [lemmatizer.lemmatize(word) for word in tokens]
    cleaned_text = ' '.join(tokens)
    return cleaned_text

# Apply text cleaning and normalization to the 'Review_Text' column
data['Cleaned_Review'] = data['Review_Text'].apply(clean_text)

# Split dataset into features (X) and target (y)
X = data['Cleaned_Review']
y = data['Sentiment']

# Initialize the TF-IDF vectorizer
tfidf_vectorizer = TfidfVectorizer()

# Fit and transform the text data
X_tfidf = tfidf_vectorizer.fit_transform(X)

# Split dataset into training and testing sets
X_train, X_test, y_train, y_test = train_test_split(X_tfidf, y, test_size=0.2, random_state=42)

# Initialize the Logistic Regression model
model = LogisticRegression()

# Train the model
model.fit(X_train, y_train)

# Save the trained model to a file
with open('model.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

# Initialize Flask application
app = Flask(__name__)

@app.route('/')
def home():
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    review = request.form['review']
    cleaned_review = clean_text(review)
    with open('model.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    prediction = model.predict([cleaned_review])[0]
    if prediction == 1:
   
